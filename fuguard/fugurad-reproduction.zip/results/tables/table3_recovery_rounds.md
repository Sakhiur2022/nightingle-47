| Method | SVHN RR(0.95) | SVHN RR(1) | EuroSAT RR(0.95) | EuroSAT RR(1) | CIFAR10 RR(0.95) | CIFAR10 RR(1) | CIFAR100 RR(0.95) | CIFAR100 RR(1) |
|---|---|---|---|---|---|---|---|---|
| Retrain | 16 | 33 | 12 | 16 | 23 | 49 | 11 | 16 |
| FedSGA | 4 | 17 | 3 | 3 | 6 | 22 | 4 | 5 |
| FU | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 |
| NoT | 22 | 50* | 9 | 18 | 22 | 50* | 14 | 22 |
| FastFedUL | 1 | 2 | 2 | 2 | 2 | 2 | 1 | 1 |
| FuGuard | 3 | 17 | 2 | 3 | 3 | 13 | 2 | 2 |
